
import java.io.*;
import java.io.IOException;
import java.util.*;
import javax.bluetooth.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

public class BlueTooth extends MIDlet implements CommandListener, DiscoveryListener {

    Display d = null;
    Thread t = null;
    Command conectar = null;
    Command prender = null;
    Command apagar = null;
    Command salir = null;
    List btDisp = null;
    Form f = null;
    private Vector dispositivos = null;
    private LocalDevice dispLocal = null;
    private DiscoveryAgent agente = null;    
    private StreamConnection conn;
    
    private String url = "btspp://98D333807EB6:1";

    InputStream in = null;
    OutputStream out = null;
    private int sled = 0;

    public BlueTooth() {
        d = Display.getDisplay(this);

        /*---------------------- Lista Dispositivos ----------------------------*/
        conectar = new Command("Conectar", Command.OK, 0);
        salir = new Command("Salir", Command.EXIT, 0);
        btDisp = new List("Lista Dispositivos", Choice.EXCLUSIVE);
        //btDisp.addCommand(conectar);
        btDisp.addCommand(salir);
        btDisp.setCommandListener(this);

        /*---------------------- Form para mensajes ----------------------------*/
        f = new Form("Conexion a dispositivo");
        prender = new Command("Prender", Command.OK, 0);
        apagar = new Command("Apagar", Command.OK, 0);
        f.addCommand(prender);
        f.addCommand(apagar);
        f.addCommand(salir);
        f.setCommandListener(this);

        /*----------------------------------------------------------------------*/
        buscarDispostivos();
    }
    
    public void conectar(){
        try {    
            conn = (StreamConnection) Connector.open(url);
            in = conn.openInputStream();
            out = conn.openOutputStream();
        } catch (IOException ex) {
            System.err.println("Error en StreamConnection" + ex.getMessage());
        }
    }
    
    public void desconectar(){
        try {                       
            in.close();
            out.close();
            conn.close();
            conn = null;
        } catch (IOException ex) {
            System.err.println("Error en StreamConnection" + ex.getMessage());
        }
    }

    public void startApp() {
        d.setCurrent(btDisp);
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
        destroyApp(true);
        notifyDestroyed();
    }

    public void commandAction(Command co, Displayable di) {        
        if (co == conectar) {
            d.setCurrent(f);
            //conectar();
        } else if (co == salir) {
            if (conn != null) {
                desconectar();
            }
            destroyApp(true);
            notifyDestroyed();
        } else if (co == prender) {
            conectar();
            if (in != null && out != null) {
                try {                    
                    out.write(("1").getBytes());                     
                    //in.read(buffer);
                    
                    //if (new String(buffer).equals("1")) {
                        f.append(new StringItem("Arduino: Led Prendido" , null)); 
                    //}                                       
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
            desconectar();
        } else if (co == apagar) {            
            conectar();
            if (in != null && out != null) {
                try {
                    out.write(("0").getBytes());                                        
                    //in.read(buffer);
                    //if (new String(buffer).equals("0")) {
                        f.append(new StringItem("Arduino: Led Apagado" , null)); 
                    //}                     
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
            desconectar();
        }

    }

    private void buscarDispostivos() {
        try {
            dispositivos = new Vector();
            dispLocal = LocalDevice.getLocalDevice();
            agente = dispLocal.getDiscoveryAgent();
            dispLocal.setDiscoverable(DiscoveryAgent.GIAC);
            agente.startInquiry(DiscoveryAgent.GIAC, this);
        } catch (BluetoothStateException ex) {
            System.err.println("En disp: " + ex.getMessage());
        }
    }

    public void deviceDiscovered(RemoteDevice rd, DeviceClass dc) {
        try {
            dispositivos.addElement(rd);
            btDisp.append(((RemoteDevice)rd).getFriendlyName(true), null);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void inquiryCompleted(int i) {
        switch (i) {
            case DiscoveryListener.INQUIRY_COMPLETED:   //Inquiry termino normalmente
                if (dispositivos.size() > 0) {      //Al menos se encontro un dispositivo                    
                    btDisp.addCommand(conectar);
                    alertar("Busqueda terminada: "+dispositivos.size(), 2000);
                } else {
                    alertar("No se encontraron dispositivos", 2000);
                }
                break;
            case DiscoveryListener.INQUIRY_ERROR:
                alertar("Error en Busqueda", 2000);
                break;
            case DiscoveryListener.INQUIRY_TERMINATED:
                alertar("Busqueda cancelada", 2000);
                break;
        }
    }

    public void serviceSearchCompleted(int transID, int respCode) {
    }

    public void servicesDiscovered(int i, ServiceRecord[] srs) {
    }

    private void alertar(String msg, int tiempo) {
        
        if (d.getCurrent() instanceof Alert) {
            ((Alert) d.getCurrent()).setString(msg);
            ((Alert) d.getCurrent()).setTimeout(tiempo);
            try {
                ((Alert) d.getCurrent()).setImage(Image.createImage("blue.png"));
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } else {
            Alert alerta = new Alert("Bluetooth");
            alerta.setString(msg);
            alerta.setTimeout(tiempo);
            try {
                alerta.setImage(Image.createImage("blue.png"));
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            d.setCurrent(alerta);
        }
    }
}
